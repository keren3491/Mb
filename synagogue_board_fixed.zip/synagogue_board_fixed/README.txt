Synagogue Message Board - Fixed Landscape Version

Files:
- index.html
- style.css
- script.js

Important:
Copy your image files into the same folder:
- biblical_1.jpeg
- biblical_2.jpeg
- biblical_3.jpeg
- biblical_4.jpeg
- biblical_5.jpeg
- biblical_6.jpeg

The middle information boxes scroll slowly upward.
Open index.html in landscape/horizontal mode.
