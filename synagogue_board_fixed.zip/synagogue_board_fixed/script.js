const NY="America/New_York", IL="Asia/Jerusalem", KEY="beautifulSynagogueBoard";
const defaults={
 parasha:"ואתחנן",
 synagogueName:"בית הכנסת אליהו הנביא",rabbiName:"מנחם מענדל הכהן שליט״א",
 shacharit:"6:30 AM",mincha:"8:00 PM",maariv:"9:10 PM",morningLesson:"9:00 AM",eveningLesson:"9:15 PM",
 fastName:"תשעה באב",fastStart:"8:21 PM",fastEnd:"8:52 PM",megillahName:"מגילת איכה",megillahTime:"לאחר תפילת ערבית",
 todayEvent:"ברביקיו קהילתי\nבחצר בית הכנסת",eventTime:"7:00 PM",
 dedication:"לעילוי נשמת זהבה חלא בת דינה זצ״ל",
 memorialDate:"נפטרה: כ״ה באייר תשפ״ו | 25 במאי 2026 | ת.נ.צ.ב.ה.",
 donors:"משפחת לוי|$1,000\nמשפחת כהן|$500\nמשפחת דוד|$360\nמשפחת ישראלי|$250\nידיד בית הכנסת|$180"
};
function getData(){try{return {...defaults,...JSON.parse(localStorage.getItem(KEY)||"{}")}}catch(e){return {...defaults}}}
function text(id,v){const el=document.getElementById(id);if(el)el.textContent=v}

function setupAutoScroll(){
 document.querySelectorAll(".cardBody").forEach(view=>{
   const track=view.querySelector(".scrollTrack");
   if(!track)return;
   view.classList.remove("autoScroll");
   view.style.removeProperty("--scroll-distance");
   view.style.removeProperty("--scroll-duration");
   track.style.transform="translateY(0)";
   const distance=Math.max(0,track.scrollHeight-view.clientHeight);
   if(distance>3){
     view.style.setProperty("--scroll-distance",distance);
     view.style.setProperty("--scroll-duration",Math.max(7,Math.min(18,7+distance/18))+"s");
     view.classList.add("autoScroll");
   }
 });
}

function render(){
 const d=getData();
 ["parasha","synagogueName","rabbiName","shacharit","mincha","maariv","morningLesson","eveningLesson","fastName","fastStart","fastEnd","megillahName","megillahTime","eventTime","dedication","memorialDate"].forEach(k=>text(k,d[k]));
 text("fastStart2",d.fastStart);text("fastEnd2",d.fastEnd);text("fastName2",d.fastName);
 document.getElementById("todayEvent").innerHTML=d.todayEvent.replace(/\n/g,"<br>");
 const list=document.getElementById("donorsList");list.innerHTML="";
 d.donors.split("\n").filter(Boolean).forEach(line=>{
   const [n,a=""]=line.split("|");const div=document.createElement("div");div.className="donor";
   div.innerHTML="<span>"+n+"</span><strong>"+a+"</strong>";list.appendChild(div);
 });
 requestAnimationFrame(()=>requestAnimationFrame(setupAutoScroll));
}
function clocks(){
 const now=new Date();
 text("nyClock",new Intl.DateTimeFormat("en-US",{timeZone:NY,hour:"2-digit",minute:"2-digit",second:"2-digit"}).format(now));
 text("israelClock",new Intl.DateTimeFormat("en-US",{timeZone:IL,hour:"2-digit",minute:"2-digit",second:"2-digit"}).format(now));
 text("civilDate",new Intl.DateTimeFormat("en-US",{timeZone:NY,weekday:"long",year:"numeric",month:"long",day:"numeric"}).format(now));
 try{text("hebrewDate",new Intl.DateTimeFormat("he-u-ca-hebrew",{timeZone:NY,day:"numeric",month:"long",year:"numeric"}).format(now))}catch(e){}
}
async function jewish(){
 try{
   const ymd=new Intl.DateTimeFormat("en-CA",{timeZone:NY,year:"numeric",month:"2-digit",day:"2-digit"}).format(new Date());
   const a=await fetch("https://www.hebcal.com/converter?cfg=json&date="+ymd+"&g2h=1&strict=1").then(r=>r.json());
   if(a.hebrew)text("hebrewDate",a.hebrew);
   const b=await fetch("https://www.hebcal.com/shabbat?cfg=json&geonameid=5128581&m=50").then(r=>r.json());
   const p=(b.items||[]).find(x=>x.category==="parashat");if(p)text("parasha",p.hebrew||p.title.replace("Parashat ",""));
   requestAnimationFrame(setupAutoScroll);
 }catch(e){}
}
let slide=0;
setInterval(()=>{const imgs=[...document.querySelectorAll("#slideshow img")];imgs[slide].classList.remove("active");slide=(slide+1)%imgs.length;imgs[slide].classList.add("active")},60000);
document.getElementById("gear").onclick=()=>{
 const d=getData(),f=document.getElementById("adminForm");
 Object.keys(defaults).forEach(k=>{if(f.elements[k])f.elements[k].value=d[k]});
 document.getElementById("modal").classList.add("open");
};
document.getElementById("close").onclick=()=>document.getElementById("modal").classList.remove("open");
document.getElementById("reset").onclick=()=>{localStorage.removeItem(KEY);render();document.getElementById("modal").classList.remove("open")};
document.getElementById("adminForm").onsubmit=e=>{
 e.preventDefault();const d={};Object.keys(defaults).forEach(k=>d[k]=e.target.elements[k].value);
 localStorage.setItem(KEY,JSON.stringify(d));render();document.getElementById("modal").classList.remove("open");
};
window.addEventListener("resize",()=>requestAnimationFrame(setupAutoScroll));
window.addEventListener("load",()=>requestAnimationFrame(()=>requestAnimationFrame(setupAutoScroll)));
render();clocks();jewish();setInterval(clocks,1000);setInterval(jewish,21600000);